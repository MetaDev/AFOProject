# ----------------------------------------------------------------------- #
# The OpenSim API is a toolkit for musculoskeletal modeling and           #
# simulation. See http://opensim.stanford.edu and the NOTICE file         #
# for more information. OpenSim is developed at Stanford University       #
# and supported by the US National Institutes of Health (U54 GM072970,    #
# R24 HD065690) and by DARPA through the Warrior Web program.             #
#                                                                         #   
# Copyright (c) 2005-2012 Stanford University and the Authors             #
#                                                                         #   
# Licensed under the Apache License, Version 2.0 (the "License");         #
# you may not use this file except in compliance with the License.        #
# You may obtain a copy of the License at                                 #
# http://www.apache.org/licenses/LICENSE-2.0.                             #
#                                                                         # 
# Unless required by applicable law or agreed to in writing, software     #
# distributed under the License is distributed on an "AS IS" BASIS,       #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or         #
# implied. See the License for the specific language governing            #
# permissions and limitations under the License.                          #
# ----------------------------------------------------------------------- #

#
# Author(s): Ayman Habib
# Stanford University
#
# Create and open a custom window

import java.util.ArrayList as ArrayList
import javax.swing.JButton as JButton

# create window and empty all contents
parametersWindow = createParametersWindow()
parametersWindow.reset();

# Hide simulation toolbar so users run thru the custom GUI only
setSimulationToolBarVisibility(0)

m = getCurrentModel()

# Create slider for vas_int_r max_isometric_force
vasint = m.getForceSet().get('vas_int_r')
maxVasintForceProperty = vasint.getPropertyByName('max_isometric_force')
parametersWindow.createKnobForProperty(maxVasintForceProperty, "Quadriceps or Thigh Muscle Force (Newtons)", m, vasint, 0., 9000.)

# soleus_r
soleus = m.getForceSet().get('soleus_r')
maxSoleusForceProperty = soleus.getPropertyByName('max_isometric_force')
parametersWindow.createKnobForProperty(maxSoleusForceProperty, "Soleus or Calf Muscle Force (Newtons)", m, soleus, 0., 9000.)

# turn angle
turn = m.getCoordinateSet().get('turn')
parametersWindow.createKnobForCoordinate(turn, 'Turn Right and Left')

#reset view
cameraParams = [-6.71, 6.47, 14.29, 4.56, 1.72, -1.36, 0.08, 0.97, -0.23, -0.57, 0.24, 0.79, 27.21]
parametersWindow.setDefaultView(cameraParams)
parametersWindow.createResetViewButton()

## run button
## This uses absolute path for setup file, could be done better for portability
parametersWindow.addToolButton("D:/Test/DDemo/Soccer/runFD.xml", "Kick...")

# Outputs
parametersWindow.addOutputQuantity("Max Ball Speed=____ meter/s", "Kinematics.Speeds.ball_tx") 

# Instructions page
createInstructionsWindow("D:/Test/DDemo/Soccer/soccerkickmodel.html")

